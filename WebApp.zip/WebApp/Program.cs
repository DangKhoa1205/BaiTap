
using WebApp.Api.Models;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFlutter", policy =>
    {
        policy.WithOrigins(
                "http://localhost:57258"
              )
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

// Đăng ký Provider
builder.Services.AddScoped<SiteProvider>();

// Đăng ký Controllers
builder.Services.AddControllers();

var app = builder.Build();

app.UseCors("AllowFlutter");

// Hỗ trợ file tĩnh
app.UseStaticFiles();

// Kích hoạt các API
app.MapControllers();

app.Run();
