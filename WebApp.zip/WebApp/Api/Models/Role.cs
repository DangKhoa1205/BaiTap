namespace WebApp.Api.Models;

public enum Role
{
    Member = 0,
    Customer = 1,
    Admin = 2
}