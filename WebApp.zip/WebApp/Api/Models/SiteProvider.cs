
namespace WebApp.Api.Models;

public class SiteProvider : BaseProvider
{
    public SiteProvider(IConfiguration configuration)
        : base(configuration)
    {
    }

    private CategoryRepository? category;

    public CategoryRepository Category =>
        category ??= new CategoryRepository(Connection);

    MemberRepository? member;

    public MemberRepository Member =>
        member ??= new MemberRepository(Connection);
}
