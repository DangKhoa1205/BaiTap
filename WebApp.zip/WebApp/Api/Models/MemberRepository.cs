using System;
using System.Data;
using Dapper;

namespace WebApp.Api.Models;

public class MemberRepository : BaseRepository
{
    public MemberRepository(IDbConnection connection)
        : base(connection)
    {
    }

    public int Add(Member obj)
    {
        if (string.IsNullOrEmpty(obj.MemberId))
        {
            obj.MemberId = Guid.NewGuid()
                .ToString("N");
        }

        obj.Password = BCrypt.Net.BCrypt.HashPassword(
            obj.Password
        );

        obj.Role = Role.Member;

        return connection.Execute(
            "AddMember",
            obj,
            commandType: CommandType.StoredProcedure
        );
    }
}