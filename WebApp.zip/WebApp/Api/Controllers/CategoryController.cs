
using Microsoft.AspNetCore.Mvc;
using WebApp.Api.Models;

namespace WebApp.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CategoryController : BaseController
{
    // GET: api/category
    [HttpGet]
    public IEnumerable<Category> GetCategories()
    {
        return Provider.Category.GetCategories();
    }

    // POST: api/category
    [HttpPost]
    public IActionResult Add(Category obj)
    {
        int result = Provider.Category.Add(obj);

        return Ok(new
        {
            message = "Thêm danh mục thành công",
            affectedRows = result
        });
    }

    [HttpGet("{id}")]
    public ActionResult<Category> GetCategory(short id)
    {
        var category = Provider.Category.GetCategory(id);

        if (category == null)
            return NotFound("Không tìm thấy danh mục");

        return Ok(category);
    }

    [HttpPut]
    public IActionResult Edit(Category obj)
    {
        int result = Provider.Category.Edit(obj);

        if (result == 0)
            return NotFound("Không tìm thấy danh mục cần sửa");

        return Ok(result);
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(short id)
    {
        int result = Provider.Category.Delete(id);

        if (result == -1)
            return Conflict("Danh mục có danh mục con, không thể xóa");

        if (result == 0)
            return NotFound("Không tìm thấy danh mục");

        return Ok(result);
    }
}
