using Microsoft.AspNetCore.Mvc;
using WebApp.Api.Models;

namespace WebApp.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : BaseController
{
    [HttpPost("register")]
    public int Register(Member obj)
    {
        ModelState.Remove(nameof(obj.MemberId));

        if (ModelState.IsValid)
        {
            obj.Role = Role.Member;
            return Provider.Member.Add(obj);    
        }
        return -2;

        
    }
}